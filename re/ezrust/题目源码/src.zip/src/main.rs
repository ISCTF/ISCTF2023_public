use std::io;
use std::time::{Instant, Duration};
use std::process::exit;
use std::thread::sleep;
use lazy_static::lazy_static;
use ctor::ctor;

fn check_time(start:Instant,end:Instant) {
    // 计算时间差
    let time = end - start;

    // 设置阈值
    let limit = Duration::from_millis(100);

    // 判断是否被调试
    if time > limit {
        println!("HaHa,Debug detected!");
        sleep(time);
        exit(1);
    }
}

fn get_input() -> Vec<u8> {
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Input error!");

    let input_len = input.trim().len();

    assert_eq!(input_len, 32, "Wrong length!");

    let mut input_vec = Vec::new();
    for c in input.trim().bytes() {
        input_vec.push(c);
    }
    
    input_vec
}

fn noname_encode<T>(arr1: [T; 32], arr2: [T; 32]) -> Vec<T>
where
    T: std::ops::BitXor<Output = T> + Copy, // 约束泛型类型参数必须实现 BitXor 特性和 Copy 特性
{
    let mut result = Vec::new(); // 创建一个空的 Vec
    for i in 0..32 {
        let start = Instant::now();
        result.push(arr1[i] ^ arr2[i]); // 将两个数组对应元素异或后的值放入 Vec
        let end = Instant::now();
        check_time(start, end);
    }
    result // 返回 Vec
}

lazy_static! {
    static ref KEY: [i8; 32] = [4, 21, 13, 59, 11, 45, 15, 19, 78, 62, 26, 47, 18, 77, 34, 34, 56, 34, 6, 76, 10, 28, 28, 19, 13, 29, 81, 80, 46, 15, 27, 12];
    static ref ORDER:[usize; 32] = [16, 28, 9, 5, 3, 18, 11, 31, 19, 24, 15, 13, 7, 25, 17, 27, 23, 2, 22, 10, 21, 6, 14, 26, 4, 8, 29, 30, 1, 12, 20, 0];
}

#[ctor]
fn attach_debugger_to_self() {
    const _STATE:&str = "I was unable to implement this function for anti-debug because I'm a beginner";
    println!("ISCTF{{F4K3f1a9}}");
}
fn main() {
    let v1:[u8; 32] = [155, 76, 114, 82, 35, 197, 165, 17, 97, 22, 142, 38, 251, 240, 107, 67, 131, 189, 172, 149, 14, 117, 237, 59, 224, 94, 49, 216, 184, 162, 239, 179];
    let v1key:[u8; 32] = [100, 179, 141, 173, 220, 58, 90, 238, 158, 233, 113, 217, 4, 15, 148, 188, 124, 66, 83, 106, 241, 138, 18, 196, 31, 161, 206, 39, 71, 93, 16, 76];
    let v2:[i8; 32] = [-105, -25, -9, -55, -69, -38, -67, -96, -57, -76, -86, -30, -36, -119, -90, -64, -75, -77, -94, -106, -60, -23, -45, -68, -97, -63, -118, -58, -93, -74, -89, -95];
    let v2key:[i8; 32] = [23, 103, 119, 73, 59, 90, 61, 32, 71, 52, 42, 98, 92, 9, 38, 64, 53, 51, 34, 22, 68, 105, 83, 60, 31, 65, 10, 70, 35, 54, 39, 33];

    let max_u8 = noname_encode(v1, v1key);
    let min_i8 = noname_encode(v2, v2key);

    println!("Welcome to the program I coded to learn basic Rust!");
    println!("Input your flag:");
    let input_vec = get_input();

    for i in 0..input_vec.len() {
        let start = Instant::now();
        if max_u8[i] + input_vec[i] != (min_i8[i] - KEY[ORDER[i]]) as u8{
            println!("Wrong! Look before you leap!");
            exit(1);
        }
        let end = Instant::now();
        check_time(start, end);
    }
    println!("Congratulations! You are right!");
}
